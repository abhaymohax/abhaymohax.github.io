# AgriLink Procurement Demo

A college-presentation prototype for recording agricultural produce purchased from small farmers.

## Features
- Farmer name, date, produce, quantity, purchase rate
- Phone and address
- Quality grade
- Payment status
- Collection location
- Quality/inspection notes
- Dashboard totals
- Search
- Delete records
- CSV export
- Browser localStorage (no database required)

## Free deployment
Use GitHub Pages:
1. Create a GitHub account.
2. Create a public repository named `YOURUSERNAME.github.io`.
3. Upload `index.html`.
4. Open repository Settings -> Pages.
5. Select the main branch as the publishing source.
6. Your site will be available at `https://YOURUSERNAME.github.io/`.

For a project repository instead, create any repository and enable Pages; the URL will generally be `https://YOURUSERNAME.github.io/REPOSITORYNAME/`.

This prototype stores data only in the browser used for the presentation. It is not suitable for real farmer data until a secure backend/database and authentication are added.
